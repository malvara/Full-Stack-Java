package com.untec.model;

import java.util.Date;

/**
 * Clase para gestionar entidad prestamo.
 */
public class Prestamo {
	/**
	 * Atributos coincidentes con tabla prestamo de BD Untec en MariaDB.
	 */
    private int prestamoId;
    private int prestamoLibro;   // Almacena el ID del libro
    private int prestamoUsuario; // Almacena el ID del usuario
    private Date prestamoFecha;  // Usamos java.util.Date para manejar la fecha en Java
    private String libroTituloTexto;
    private String usuarioNombreTexto;
    /**
     * Constructor vacío.
     */
    public Prestamo() {
    }
    /**
     * Constructor completo con ID (para consultas a MariaDB).
     * @param prestamoId identificador de préstamo.
     * @param prestamoLibro identificador del libro.
     * @param prestamoUsuario identificador del usuario.
     * @param prestamoFecha fecha del préstamo.
     */
    public Prestamo(int prestamoId, int prestamoLibro, int prestamoUsuario, Date prestamoFecha) {
        this.prestamoId = prestamoId;
        this.prestamoLibro = prestamoLibro;
        this.prestamoUsuario = prestamoUsuario;
        this.prestamoFecha = prestamoFecha;
    }
    /**
     * Constructor completo sin ID (para operaciones de agregación).
     * @param prestamoLibro identificador del libro.
     * @param prestamoUsuario identificador del usuario.
     * @param prestamoFecha fecha del préstamo.
     */
    public Prestamo(int prestamoLibro, int prestamoUsuario, Date prestamoFecha) {
        this.prestamoLibro = prestamoLibro;
        this.prestamoUsuario = prestamoUsuario;
        this.prestamoFecha = prestamoFecha;
    }
    /**
     * Constructor completo para listados con INNER JOIN.
     * @param prestamoId identificador de préstamo.
     * @param libroTituloTexto título del libro prestado.
     * @param usuarioNombreTexto nombre del usuario prestatario.
     * @param prestamoFecha fecha del préstamo.
     */
    public Prestamo(int prestamoId, String libroTituloTexto, String usuarioNombreTexto, Date prestamoFecha) {
        this.prestamoId = prestamoId;
        this.libroTituloTexto = libroTituloTexto;
        this.usuarioNombreTexto = usuarioNombreTexto;
        this.prestamoFecha = prestamoFecha;
    }
    /**
     * Método para obtener ID del préstamo.
     * @return prestamoId identificador del préstamo.
     */
    public int getPrestamoId() {
        return prestamoId;
    }
    /**
     * Método para modificar ID del préstamo.
     * @param prestamoId nuevo identificador del préstamo.
     */
    public void setPrestamoId(int prestamoId) {
        this.prestamoId = prestamoId;
    }
    /**
     * Método para obtener ID del libro prestado.
     * @return prestamoLibro identificador del libro prestado.
     */
    public int getPrestamoLibro() {
        return prestamoLibro;
    }
    /**
     * Método para modificar ID del libro prestado.
     * @param prestamoLibro nuevo identificador de libro prestado.
     */
    public void setPrestamoLibro(int prestamoLibro) {
        this.prestamoLibro = prestamoLibro;
    }
    /**
     * Método para obtener ID del usuario prestatario.
     * @return prestamoUsuario identificador del usuario prestatario.
     */
    public int getPrestamoUsuario() {
        return prestamoUsuario;
    }
    /**
     * Método para modificar ID del usuario prestatario.
     * @param prestamoUsuario identificador del usuario prestatario.
     */
    public void setPrestamoUsuario(int prestamoUsuario) {
        this.prestamoUsuario = prestamoUsuario;
    }
    /**
     * Método para obtener la fecha del préstamo.
     * @return prestamoFecha fecha del préstamo.
     */
    public Date getPrestamoFecha() {
        return prestamoFecha;
    }
    /**
     * Método para modificar fecha del préstamo.
     * @param prestamoFecha
     */
    public void setPrestamoFecha(Date prestamoFecha) {
        this.prestamoFecha = prestamoFecha;
    }
    /**
     * Método para obtener el título del préstamo.
     * @return libroTituloTexto nombre del título del libro prestado.
     */
    public String getLibroTituloTexto() { 
    	return libroTituloTexto; 
	}
    /**
     * Método para modificar el título del libro prestado.
     * @param libroTituloTexto nuevo título del libro.
     */
    public void setLibroTituloTexto(String libroTituloTexto) {
    	this.libroTituloTexto = libroTituloTexto;
	}
    /**
     * Método para obtener el nombre del usario prestatario.
     * @return usuarioNombreTexto nombre del usuario prestatario.
     */
    public String getUsuarioNombreTexto() {
    	return usuarioNombreTexto;
	}
    /**
     * Método para modificar el usuario del libro prestado.
     * @param usuarioNombreTexto nuevo usuario prestatario.
     */
    public void setUsuarioNombreTexto(String usuarioNombreTexto) {
    	this.usuarioNombreTexto = usuarioNombreTexto;
	}
    /**
     * Método que genera argumento para imprimir información del préstamo.
     */
    @Override
    public String toString() {
        return "Prestamo [ID=" + prestamoId + ", LibroID=" + prestamoLibro + 
               ", UsuarioID=" + prestamoUsuario + ", Fecha=" + prestamoFecha + "]";
    }
}