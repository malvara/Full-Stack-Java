package com.untec.servlet;

import java.util.Date;
import java.util.List;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import com.untec.dao.PrestamoDAO;
import com.untec.dao.LibroDAO;
import com.untec.dao.UsuarioDAO;
import com.untec.model.Prestamo;
import com.untec.model.Libro;
import com.untec.model.Usuario;

/**
 * Servlet que controla la asignación de libros a lectores y llama 
 * a las consultas avanzadas que cruzaron datos con alias de 
 * texto, permitiendo filtros avanzados.
 */
@WebServlet("/Prestamoweb")
public class PrestamoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PrestamoDAO prestamoDAO = new PrestamoDAO();
	LibroDAO libroDAO = new LibroDAO();
	UsuarioDAO usuarioDAO = new UsuarioDAO();
	/**
	 * Constructor por defecto.
	 */
    public PrestamoServlet() {
        super();
    }
    /**
     * Método que atiende peticiones de lectura o eliminación de datos.
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
	    Usuario usuarioLogueado = (Usuario) sesion.getAttribute("usuarioSesion");
	    if (usuarioLogueado == null) {
	        response.sendRedirect("index.jsp");
	        return;
	    }
		String opcion = request.getParameter("opcion");
	    if ("eliminar".equals(opcion) && "admin".equals(usuarioLogueado.getUsuarioRol())) {
	        int id = Integer.parseInt(request.getParameter("id"));
	        prestamoDAO.eliminar(id);
	        response.sendRedirect("Prestamoweb");
	        return;
	    }
        List<Prestamo> listaDePrestamos;
        if ("admin".equals(usuarioLogueado.getUsuarioRol())) {
            listaDePrestamos = prestamoDAO.listarTodos();
        } else {
            listaDePrestamos = prestamoDAO.listarPorUsuario(usuarioLogueado.getUsuarioId());
        }
    	List<Libro> listaDeLibros = libroDAO.listarTodos();
        List<Usuario> listaDeUsuarios = usuarioDAO.listarTodos();
        request.setAttribute("listaPrestamosWeb", listaDePrestamos);
        request.setAttribute("listaLibrosMenu", listaDeLibros);
        request.setAttribute("listaUsuariosMenu", listaDeUsuarios);
        RequestDispatcher dispatcher = request.getRequestDispatcher("prestamos.jsp");
        dispatcher.forward(request, response);
	}
	/**
	 * Método que atiende peticiones de agregación o actualización de datos.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        String idStr = request.getParameter("txtId");
        int idLibro = Integer.parseInt(request.getParameter("selectLibro"));
        int idUsuario = Integer.parseInt(request.getParameter("selectUsuario"));
        // Crea un registro con la fecha y hora exacta actual de la transacción.
        Prestamo prestamo = new Prestamo(idLibro, idUsuario, new Date());

        if (idStr == null || idStr.isEmpty()) {
            prestamoDAO.agregar(prestamo);
        } else {
            prestamo.setPrestamoId(Integer.parseInt(idStr));
            prestamoDAO.actualizar(prestamo);
        }
        response.sendRedirect("Prestamoweb");
	}
}
