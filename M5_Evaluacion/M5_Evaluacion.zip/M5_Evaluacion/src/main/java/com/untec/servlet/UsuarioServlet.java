package com.untec.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import com.untec.dao.UsuarioDAO;
import com.untec.model.Usuario;

/**
 * Servlet encargado de gestionar el listado de 
 * usuarios, registrar nuevos lectores y 
 * capturar las peticiones de autenticación (Login).
 */
@WebServlet("/Usuarioweb")
public class UsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    /**
     * Constructor por defecto.
     */
    public UsuarioServlet() {
        super();
    }
    /**
     * Método que atiende peticiones de lectura o eliminación de datos.
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opcion = request.getParameter("opcion");
		if ("eliminar".equals(opcion)) {
            // Captura el ID desde la URL para borrar un usuario
            int id = Integer.parseInt(request.getParameter("id"));
            usuarioDAO.eliminar(id);
            response.sendRedirect("Usuarioweb");
            return;
        }
		// Lista todos los usuarios.
        List<Usuario> listaDeUsuarios = usuarioDAO.listarTodos();
        request.setAttribute("listaUsuariosWeb", listaDeUsuarios);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("usuarios.jsp");
        dispatcher.forward(request, response);
    }
	/**
	 * Método que atiende peticiones de agregación o actualización de datos.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        String opcion = request.getParameter("opcion");
        if ("login".equals(opcion)) {
            // Procesa el inicio de sesión
            String email = request.getParameter("txtEmail");
            String pass = request.getParameter("txtPassword");
            Usuario usuarioLogueado = usuarioDAO.validarUsuario(email, pass);
            if (usuarioLogueado != null) {
                // Guarda usuario en sesión web para proteger tus páginas.
                HttpSession sesion = request.getSession();
                sesion.setAttribute("usuarioSesion", usuarioLogueado);
                response.sendRedirect("Libroweb");
                return;
            } else {
                request.setAttribute("mensajeError", "Credenciales incorrectas. Inténtalo de nuevo.");
                request.getRequestDispatcher("index.jsp").forward(request, response);
                return;
            }
        } else {
            // Registrar o actualizar usuario (Formulario).
            String idStr = request.getParameter("txtId");
            String nombre = request.getParameter("txtNombre");
            String email = request.getParameter("txtEmail");
            String pass = request.getParameter("txtPassword");

            Usuario usuario = new Usuario(nombre, email, pass);

            if (idStr == null || idStr.isEmpty()) {
                usuarioDAO.agregar(usuario);
            } else {
                usuario.setUsuarioId(Integer.parseInt(idStr));
                usuarioDAO.actualizar(usuario);
            }
            response.sendRedirect("Usuarioweb");
        }
	}
}
