package com.untec.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase que conecta MariaDB con JDBC.
 * Define parámetros de conexión y método para crear objeto de conexión singleton.
 */
public class Conexion {
	/**
	 * Atributos necesarios para conexión a MariaDB.
	 */
	private static Connection conexionUnica = null;  
	private static final String URL = "jdbc:mariadb://localhost:3307/Untec?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "admin";
    private static final String DRIVER = "org.mariadb.jdbc.Driver";
    /**
     * Constructor bloqueado para garantizar la instancia única.
     */
    private Conexion() {
    }
    /**
     * Método de acceso global (Singleton)
     * @return conexionUnica devuelve conexión existente o crea una si no existe.
     */
    public static Connection getConexion() {
        try {
        	if(conexionUnica==null || conexionUnica.isClosed()) {
        		Class.forName(DRIVER);
                conexionUnica = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("[Singleton] ¡Nueva conexión exitosa Untec!");
        	}
            
        } 
        catch (ClassNotFoundException e) {
            System.err.println("[Error] No se encontró el Driver de MariaDB: " + e.getMessage());
        }
        catch (SQLException e) {
            System.err.println("[Error] Falló la conexión a MariaDB: " + e.getMessage());
        }
        return conexionUnica;
    }
}