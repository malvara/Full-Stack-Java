package com.untec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.untec.conexion.Conexion;
import com.untec.model.Prestamo;

/**
 * Clase que gestiona sentencias SQL entre modelo y BD Untec en MariaDB.
 */
public class PrestamoDAO {
	/**
	 * Constantes que contienen sentencias SQL.
	 */
	private static final String SQL_INSERT = "INSERT INTO prestamo (prestamo_libro, prestamo_usuario, prestamo_fecha) VALUES (?, ?, ?)";
	private static final String SQL_UPDATE = "UPDATE prestamo SET prestamo_libro = ?, prestamo_usuario = ?, prestamo_fecha = ? WHERE prestamo_id = ?";
	private static final String SQL_DELETE = "DELETE FROM prestamo WHERE prestamo_id = ?";
	private static final String SQL_SELECT_TODOS = 
        "SELECT p.prestamo_id, l.libro_titulo AS prestamo_libro_texto, u.usuario_nombre AS prestamo_usuario_texto, p.prestamo_fecha " +
        "FROM prestamo p " +
        "INNER JOIN libro l ON p.prestamo_libro = l.libro_id " +
        "INNER JOIN usuario u ON p.prestamo_usuario = u.usuario_id";
    private static final String SQL_SELECT_BY_LIBRO = 
        "SELECT p.prestamo_id, l.libro_titulo AS prestamo_libro_texto, u.usuario_nombre AS prestamo_usuario_texto, p.prestamo_fecha " +
        "FROM prestamo p " +
        "INNER JOIN libro l ON p.prestamo_libro = l.libro_id " +
        "INNER JOIN usuario u ON p.prestamo_usuario = u.usuario_id " +
        "WHERE p.prestamo_libro = ?";
    private static final String SQL_SELECT_BY_USUARIO = 
        "SELECT p.prestamo_id, l.libro_titulo AS prestamo_libro_texto, u.usuario_nombre AS prestamo_usuario_texto, p.prestamo_fecha " +
        "FROM prestamo p " +
        "INNER JOIN libro l ON p.prestamo_libro = l.libro_id " +
        "INNER JOIN usuario u ON p.prestamo_usuario = u.usuario_id " +
        "WHERE p.prestamo_usuario = ?";
	/**
	 * Agregar un préstamo a BD Untec en MariaDB.
	 * @param prestamo objeto préstamo con datos para ingresar.
	 * @return boolean true si se insertó con éxito, false en caso contrario.
	 */
	public boolean agregar(Prestamo prestamo) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean insertado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_INSERT);
            ps.setInt(1, prestamo.getPrestamoLibro());
            ps.setInt(2, prestamo.getPrestamoUsuario());
            // Convertimos la fecha de java.util.Date a java.sql.Date para MariaDB.
            ps.setDate(3, new java.sql.Date(prestamo.getPrestamoFecha().getTime()));
            if (ps.executeUpdate() > 0) {
                insertado = true;
                System.out.println("[PrestamoDAO] Préstamo registrado correctamente.");
            }
        } catch (SQLException e) {
            System.err.println("[PrestamoDAO Error] Error al agregar préstamo: " + e.getMessage());
        } finally {
            cerrarRecursos(null, ps);
        }
        return insertado;
    }
	/**
	 * Método que ctualiza datos de préstamo existente por su ID.
	 * @param prestamo objeto préstamo con datos para ingresar.
	 * @return boolean true si se actualizó con éxito, false en caso contrario.
     */
    public boolean actualizar(Prestamo prestamo) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean actualizado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_UPDATE);
            ps.setInt(1, prestamo.getPrestamoLibro());
            ps.setInt(2, prestamo.getPrestamoUsuario());
            ps.setDate(3, new java.sql.Date(prestamo.getPrestamoFecha().getTime()));
            ps.setInt(4, prestamo.getPrestamoId());
            if (ps.executeUpdate() > 0) {
                actualizado = true;
                System.out.println("[PrestamoDAO] Préstamo ID " + prestamo.getPrestamoId() + " actualizado.");
            }
        }
        catch (SQLException e) {
            System.err.println("[PrestamoDAO Error] Error al actualizar préstamo: " + e.getMessage());
        }
        finally {
            cerrarRecursos(null, ps);
        }
        return actualizado;
    }
    /**
     * Método que elimina datos de préstamo existente por su ID.
     * @param prestamoId identificador del préstamo a eliminar.
     * @return boolean true si se eliminó con éxito, false en caso contrario.
     */
    public boolean eliminar(int prestamoId) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean eliminado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_DELETE);
            ps.setInt(1, prestamoId);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
                System.out.println("[PrestamoDAO] Préstamo ID " + prestamoId + " eliminado.");
            }
        }
        catch (SQLException e) {
            System.err.println("[PrestamoDAO Error] Error al eliminar préstamo: " + e.getMessage());
        }
        finally {
            cerrarRecursos(null, ps);
        }
        return eliminado;
    }
    /**
     * Método que lista todos los préstamos en BD MariaDB.
     * @return List<Prestamo> lista contiene el listado de préstamos realizados en java.
     */
    public List<Prestamo> listarTodos() {
        List<Prestamo> lista = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_SELECT_TODOS);
            rs = ps.executeQuery();
            while (rs.next()) {
                Prestamo p = new Prestamo(
                    rs.getInt("prestamo_id"),
                    rs.getString("prestamo_libro_texto"),
                    rs.getString("prestamo_usuario_texto"),
                    rs.getTimestamp("prestamo_fecha") // Trae la fecha completa de MariaDB
                );
                lista.add(p);
            }
            System.out.println("📦 [PrestamoDAO] Se listaron " + lista.size() + " préstamos globales.");
        } catch (SQLException e) {
            System.err.println("❌ [PrestamoDAO Error] Error en listarTodos: " + e.getMessage());
        } finally {
            cerrarRecursos(rs, ps);
        }
        return lista;
    }
    /**
     * Método para listar préstamos por ID Libro.
     * @param idLibro identificador libro.
     * @return List<Prestamo> lista contiene listado de libros préstados con ID libro entregado en java.
     */
    public List<Prestamo> listarPorLibro(int idLibro) {
        List<Prestamo> lista = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_SELECT_BY_LIBRO);
            ps.setInt(1, idLibro);
            rs = ps.executeQuery();
            while (rs.next()) {
                Prestamo p = new Prestamo(
                    rs.getInt("prestamo_id"),
                    rs.getString("prestamo_libro_texto"),
                    rs.getString("prestamo_usuario_texto"),
                    rs.getTimestamp("prestamo_fecha")
                );
                lista.add(p);
            }
        }
        catch (SQLException e) {
            System.err.println("[PrestamoDAO Error] Error en listarPorLibro: " + e.getMessage());
        }
        finally {
            cerrarRecursos(rs, ps);
        }
        return lista;
    }
    /**
     * Método para listar préstamos por ID usuario.
     * @param idUsuario identificador del usuario.
     * @return List<Prestamo> lista contiene listado de libros préstados con ID usuario entregado en java.
     */
    public List<Prestamo> listarPorUsuario(int idUsuario) {
        List<Prestamo> lista = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_SELECT_BY_USUARIO);
            ps.setInt(1, idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                Prestamo p = new Prestamo(
                    rs.getInt("prestamo_id"),
                    rs.getString("prestamo_libro_texto"),
                    rs.getString("prestamo_usuario_texto"),
                    rs.getTimestamp("prestamo_fecha")
                );
                lista.add(p);
            }
        }
        catch (SQLException e) {
            System.err.println("[PrestamoDAO Error] Error en listarPorUsuario: " + e.getMessage());
        }
        finally {
            cerrarRecursos(rs, ps);
        }
        return lista;
    }
    /**
     * Método auxiliar privado para reducir código repetitivo al cerrar flujos.
     * @param rs objeto ResultSet tabla virtual con filas encontradas.
     * @param ps objeto PreparedStatement objeto de Java JDBC que sirve para ejecutar consultas SQL.
     */
    private void cerrarRecursos(ResultSet rs, PreparedStatement ps) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
        }
        catch (SQLException e) {
        	System.err.println("[PrestamoDAO Error] Error al liberar recursos: " + e.getMessage());
        }
    }
}