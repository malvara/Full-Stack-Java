package com.untec.conexion;

import java.util.Date;
import java.util.List;
import com.untec.dao.LibroDAO;
import com.untec.dao.PrestamoDAO;
import com.untec.dao.UsuarioDAO;
import com.untec.model.Libro;
import com.untec.model.Prestamo;
import com.untec.model.Usuario;

public class PruebaSistema {

	public static void main(String[] args) {
		System.out.println("====== INICIANDO DIAGNÓSTICO DE LA BIBLIOTECA DIGITAL ======\n");

        // 1. INSTANCIAR LOS DAOs
        LibroDAO libroDAO = new LibroDAO();
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        PrestamoDAO prestamoDAO = new PrestamoDAO();

        // --------------------------------------------------------------------
        // TEST 1: LISTADO DE LIBROS (Debería traer los 50 registros)
        // --------------------------------------------------------------------
        System.out.println("=== TEST 1: Trayendo catálogo de libros de MariaDB ===");
        List<Libro> libros = libroDAO.listarTodos();
        if (!libros.isEmpty()) {
            // Imprimimos solo los primeros 3 para no saturar la consola
            System.out.println("Muestra de los primeros 3 libros encontrados:");
            for (int i = 0; i < Math.min(3, libros.size()); i++) {
                System.out.println("   " + libros.get(i));
            }
        } else {
            System.err.println("No se encontraron libros en la base de datos.");
        }
        System.out.println();

        // --------------------------------------------------------------------
        // TEST 2: LISTADO DE USUARIOS (Debería traer los 30 registros)
        // --------------------------------------------------------------------
        System.out.println("=== TEST 2: Trayendo lista de usuarios/lectores ===");
        List<Usuario> usuarios = usuarioDAO.listarTodos();
        if (!usuarios.isEmpty()) {
            System.out.println("Muestra de los primeros 2 usuarios encontrados:");
            for (int i = 0; i < Math.min(2, usuarios.size()); i++) {
                System.out.println("   " + usuarios.get(i));
            }
        } else {
            System.err.println("No se encontraron usuarios.");
        }
        System.out.println();

        // --------------------------------------------------------------------
        // TEST 3: LISTADO DE PRÉSTAMOS CON INNER JOIN (Los 40 registros cruzados)
        // --------------------------------------------------------------------
        System.out.println("=== TEST 3: Trayendo préstamos cruzados con INNER JOIN ===");
        List<Prestamo> prestamos = prestamoDAO.listarTodos();
        if (!prestamos.isEmpty()) {
            System.out.println("Muestra de los primeros 2 préstamos (Verificando Alias de Texto):");
            for (int i = 0; i < Math.min(2, prestamos.size()); i++) {
                Prestamo p = prestamos.get(i);
                // Imprimimos usando los nuevos getters de texto que configuramos con los Alias SQL
                System.out.println("   [Préstamo ID=" + p.getPrestamoId() + "] " +
                                   "Lector: " + p.getUsuarioNombreTexto() + " | " +
                                   "Libro: \"" + p.getLibroTituloTexto() + "\" | " +
                                   "Fecha: " + p.getPrestamoFecha());
            }
        } else {
            System.err.println("No se encontraron registros de préstamos.");
        }
        System.out.println();

        // --------------------------------------------------------------------
        // TEST 4: PROBAR ACCIÓN CRUD (Insertar un libro de prueba temporal)
        // --------------------------------------------------------------------
        System.out.println("=== TEST 4: Insertando un nuevo libro desde Java ===");
        Libro nuevoLibro = new Libro("Patrones de Diseño en Java", "Gof & Peers", 5, "Arquitectura");
        boolean exitoInsert = libroDAO.agregar(nuevoLibro);
        if (exitoInsert) {
            System.out.println("¡ÉXITO TOTAL! El backend y los cimientos están listos al 100%.");
        } else {
            System.err.println("Falló la inserción del libro. Revisa los tipos de datos.");
        }
        System.out.println("\n====== FIN DEL DIAGNÓSTICO ======");
	}
}
