package com.untec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.untec.conexion.Conexion;
import com.untec.model.Usuario;
/**
 * Clase que gestiona sentencias SQL entre modelo y BD Untec en MariaDB.
 */
public class UsuarioDAO {
	/**
	 * Constantes que contienen sentencias SQL.
	 */
	private static final String SQL_SELECT_TODOS = "SELECT * FROM usuario";
    private static final String SQL_INSERT       = "INSERT INTO usuario (usuario_nombre, usuario_email, usuario_password) VALUES (?, ?, ?)";
    private static final String SQL_UPDATE       = "UPDATE usuario SET usuario_nombre = ?, usuario_email = ?, usuario_password = ? WHERE usuario_id = ?";
    private static final String SQL_DELETE       = "DELETE FROM usuario WHERE usuario_id = ?";
    private static final String SQL_LOGIN        = "SELECT * FROM usuario WHERE usuario_email = ? AND usuario_password = ?";
    /**
     * Agregar un usuario a BD Untec en MariaDB.
     * @param usuario objeto usuario con datos para ingresar.
     * @return boolean true si se insertó con éxito, false en caso contrario.
     */
    public boolean agregar(Usuario usuario) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean insertado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_INSERT);
            ps.setString(1, usuario.getUsuarioNombre());
            ps.setString(2, usuario.getUsuarioEmail());
            ps.setString(3, usuario.getUsuarioPassword());
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                insertado = true;
                System.out.println("[UsuarioDAO] Usuario registrado con éxito: " + usuario.getUsuarioNombre());
            }
        } 
        catch (SQLException e) {
            System.err.println("❌ [UsuarioDAO Error] Error al agregar usuario: " + e.getMessage());
        }
        finally {
            try {
                if (ps != null) ps.close();
            }
            catch (SQLException e) {
                System.err.println("❌ [UsuarioDAO Error] Error al cerrar recursos en agregar: " + e.getMessage());
            }
        }
        return insertado;
    }
    /**
     * Método que ctualiza datos de usuario existente por su ID.
     * @param usuario objeto Usuario con datos para actualizar.
     * @return boolean true si se actualizó con éxito, false en caso contrario.
     */
    public boolean actualizar(Usuario usuario) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean actualizado = false;

        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_UPDATE);
            
            ps.setString(1, usuario.getUsuarioNombre());
            ps.setString(2, usuario.getUsuarioEmail());
            ps.setString(3, usuario.getUsuarioPassword());
            ps.setInt(4, usuario.getUsuarioId()); // Posición 4: El ID va al final debido al WHERE usuario_id = ?

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                actualizado = true;
                System.out.println("🔄 [UsuarioDAO] Usuario con ID " + usuario.getUsuarioId() + " actualizado con éxito.");
            }

        } catch (SQLException e) {
            System.err.println("❌ [UsuarioDAO Error] Error al actualizar usuario: " + e.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("❌ [UsuarioDAO Error] Error al cerrar recursos en actualizar: " + e.getMessage());
            }
        }
        return actualizado;
    }
    /**
     * Método que elimina datos de usuario existente por su ID.
     * @param usuarioId identificador del usuario a eliminar.
     * @return boolean true si se eliminó con éxito, false en caso contrario.
     */
    public boolean eliminar(int usuarioId) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean eliminado = false;

        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_DELETE);
            
            ps.setInt(1, usuarioId);

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                eliminado = true;
                System.out.println("🗑️ [UsuarioDAO] Usuario con ID " + usuarioId + " eliminado de la base de datos.");
            }

        } catch (SQLException e) {
            System.err.println("❌ [UsuarioDAO Error] Error al eliminar usuario: " + e.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("❌ [UsuarioDAO Error] Error al cerrar recursos en eliminar: " + e.getMessage());
            }
        }
        return eliminado;
    }
    /**
     * Método que lista todos los usuarios en BD MariaDB.
     * @return List<Usuario> listaUsuarios Lista de usuarios en java.
     */
    public List<Usuario> listarTodos() {
        List<Usuario> listaUsuarios = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_SELECT_TODOS);
            rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("usuario_id");
                String nombre = rs.getString("usuario_nombre");
                String email = rs.getString("usuario_email");
                String password = rs.getString("usuario_password");
                String rol = rs.getString("usuario_rol"); 

                Usuario usuario = new Usuario(id, nombre, email, password, rol);
                listaUsuarios.add(usuario);
            }
            System.out.println("📦 [UsuarioDAO] Se listaron con éxito " + listaUsuarios.size() + " usuarios de MariaDB.");

        } catch (SQLException e) {
            System.err.println("❌ [UsuarioDAO Error] Error al listar usuarios: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("❌ [UsuarioDAO Error] Error al cerrar recursos en listarTodos: " + e.getMessage());
            }
        }
        return listaUsuarios;
    }
    /**
     * Método que valida email y contraseña para el inicio de sesión (Login)
     * @param email correo electrónico del usuario.
     * @param password contraseña del usuario.
     * @return usuarioValidado objeto Usuario si las credenciales son correctas, NULL en caso contrario.
     */
    public Usuario validarUsuario(String email, String password) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Usuario usuarioValidado = null;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_LOGIN);
            ps.setString(1, email);
            ps.setString(2, password);
            //ps.setString(2, rol);
            rs = ps.executeQuery();
            if (rs.next()) {
                usuarioValidado = new Usuario();
                usuarioValidado.setUsuarioId(rs.getInt("usuario_id"));
                usuarioValidado.setUsuarioNombre(rs.getString("usuario_nombre"));
                usuarioValidado.setUsuarioEmail(rs.getString("usuario_email"));
                usuarioValidado.setUsuarioRol(rs.getString("usuario_rol"));
                // Omitimos la contraseña por seguridad en la aplicación
            }
        }
        catch (SQLException e) {
            System.err.println("[UsuarioDAO Error] Error en la autenticación: " + e.getMessage());
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            }
            catch (SQLException e) {
                System.err.println("[UsuarioDAO Error] Error al cerrar recursos en validarUsuario: " + e.getMessage());
            }
        }
        return usuarioValidado;
    }

}
