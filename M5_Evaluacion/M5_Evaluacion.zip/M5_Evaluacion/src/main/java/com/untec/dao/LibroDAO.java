package com.untec.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.untec.conexion.Conexion;
import com.untec.model.Libro;

/**
 * Clase que gestiona sentencias SQL entre modelo y BD Untec en MariaDB.
 */
public class LibroDAO {
	/**
	 * Constantes que contienen sentencias SQL.
	 */
	private static final String SQL_SELECT_TODOS = "SELECT * FROM libro";
	private static final String SQL_INSERT       = "INSERT INTO libro (libro_titulo, libro_autor, libro_copias, libro_tema) VALUES (?, ?, ?, ?)";
	private static final String SQL_UPDATE       = "UPDATE libro SET libro_titulo = ?, libro_autor = ?, libro_copias = ?, libro_tema = ? WHERE libro_id = ?";
	private static final String SQL_DELETE       = "DELETE FROM libro WHERE libro_id = ?";
	/**
	 * Método que agrega libro a BD Untec en MariaDB.
	 * @param libro objeto Libro con datos para ingresar.
	 * @return boolean true si se insertó con éxito, false en caso contrario.
	 */
    public boolean agregar(Libro libro) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean insertado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_INSERT);
            ps.setString(1, libro.getLibroTitulo());
            ps.setString(2, libro.getLibroAutor());
            ps.setInt(3, libro.getLibroCopias());
            ps.setString(4, libro.getLibroTema());
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                insertado = true;
                System.out.println("[LibroDAO] Libro agregado con éxito: " + libro.getLibroTitulo());
            }
        }
        catch (SQLException e) {
            System.err.println("[LibroDAO Error] Error al agregar el libro: " + e.getMessage());
        } 
        finally {
            try {
                if (ps != null) ps.close();
            } 
            catch (SQLException e) {
                System.err.println("[LibroDAO Error] Error al cerrar recursos en agregar: " + e.getMessage());
            }
        }
        return insertado;
    } 
    /**
     * Método que ctualiza datos de libro existente por su ID.
     * @param libro objeto Libro con datos para actualizar.
     * @return boolean true si se actualizó con éxito, false en caso contrario.
     */
    public boolean actualizar(Libro libro) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean actualizado = false;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_UPDATE);
            ps.setString(1, libro.getLibroTitulo());
            ps.setString(2, libro.getLibroAutor());
            ps.setInt(3, libro.getLibroCopias());
            ps.setString(4, libro.getLibroTema());
            ps.setInt(5, libro.getLibroId());
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                actualizado = true;
                System.out.println("[LibroDAO] Libro con ID " + libro.getLibroId() + " actualizado con éxito.");
            }
        }
        catch (SQLException e) {
            System.err.println("[LibroDAO Error] Error al actualizar el libro: " + e.getMessage());
        }
        finally {
            try {
                if (ps != null) ps.close();
            }
            catch (SQLException e) {
                System.err.println("[LibroDAO Error] Error al cerrar recursos en actualizar: " + e.getMessage());
            }
        }
        return actualizado;
    }
    /**
     * Método que elimina datos de libro existente por su ID.
     * @param libroId identificador del libro a eliminar.
     * @return boolean true si se eliminó con éxito, false en caso contrario.
     */
    public boolean eliminar(int libroId) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean eliminado = false;

        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_DELETE);
            ps.setInt(1, libroId);
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                eliminado = true;
                System.out.println("[LibroDAO] Libro con ID " + libroId + " eliminado de la base de datos.");
            }
        } 
        catch (SQLException e) {
            System.err.println("[LibroDAO Error] Error al eliminar el libro: " + e.getMessage());
        }
        finally {
            try {
                if (ps != null) ps.close();
            }
            catch (SQLException e) {
                System.err.println("[LibroDAO Error] Error al cerrar recursos en eliminar: " + e.getMessage());
            }
        }
        return eliminado;
    }
	/**
	 * Método que lista todos los libros en BD MariaDB.
	 * @return List<Libro> listaLibros Lista de libros en java.
	 */
	public List<Libro> listarTodos() {
        List<Libro> listaLibros = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Conexion.getConexion();
            ps = conn.prepareStatement(SQL_SELECT_TODOS);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("libro_id");
                String titulo = rs.getString("libro_titulo");
                String autor = rs.getString("libro_autor");
                int copias = rs.getInt("libro_copias");
                String tema = rs.getString("libro_tema");
                Libro libro = new Libro(id, titulo, autor, copias, tema);
                listaLibros.add(libro);
            }
            System.out.println("[LibroDAO] Se listaron con éxito " + listaLibros.size() + " libros de MariaDB.");
        }
        catch (SQLException e) {
            System.err.println("[LibroDAO Error] Error al listar los libros: " + e.getMessage());
        } 
        finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } 
            catch (SQLException e) {
                System.err.println("[LibroDAO Error] Error al cerrar recursos: " + e.getMessage());
            }
        }
        return listaLibros;
    }
}

