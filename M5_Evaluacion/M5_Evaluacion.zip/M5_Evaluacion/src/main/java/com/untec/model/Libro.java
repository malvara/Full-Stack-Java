package com.untec.model;
/**
 * Clase que gestiona la entidad Libro.
 */
public class Libro {
	/**
	 * Atributos coincidentes con tabla libro de BD Untec en MariaDB.
	 */
	private int libroId;
    private String libroTitulo;
    private String libroAutor;
    private int libroCopias;
    private String libroTema;
    /**
     * Constructor vacío (obligatorio para especificaciones web de Java)
     */
    public Libro() {
    }
    /**
     * Constructor completo con ID (para consultas a MariaDB).
     * @param libroId identificador del libro.
     * @param libroTitulo título del libro.
     * @param libroAutor autor del libro.
     * @param libroCopias cantidad de ejemplares del libro.
     * @param libroTema categoría temática del libro.
     */
    public Libro(int libroId, String libroTitulo, String libroAutor, int libroCopias, String libroTema) {
        this.libroId = libroId;
        this.libroTitulo = libroTitulo;
        this.libroAutor = libroAutor;
        this.libroCopias = libroCopias;
        this.libroTema = libroTema;
    }
    /**
     * Constructor completo sin ID (para operaciones de agregación).
     * @param libroTitulo título del libro.
     * @param libroAutor autor del libro.
     * @param libroCopias cantidad de ejemplares del libro.
     * @param libroTema categoría temática del libro.
     */
    public Libro(String libroTitulo, String libroAutor, int libroCopias, String libroTema) {
        this.libroTitulo = libroTitulo;
        this.libroAutor = libroAutor;
        this.libroCopias = libroCopias;
        this.libroTema = libroTema;
    }
    /**
     * Obtener ID del libro.
     * @return libroID identificador del libro.
     */
    public int getLibroId() {
        return libroId;
    }
    /**
     * Modificar el ID del libro.
     * @param libroId valor ID del  libro.
     */
    public void setLibroId(int libroId) {
        this.libroId = libroId;
    }
    /**
     * Método para obtener el título del libro.
     * @return libroTitulo título del libro.
     */
    public String getLibroTitulo() {
        return libroTitulo;
    }
    /**
     * Método para modificar el título del libro.
     * @param libroTitulo nuevo título del libro.
     */
    public void setLibroTitulo(String libroTitulo) {
        this.libroTitulo = libroTitulo;
    }
    /**
     * Método para obtener el autor del libro.
     * @return libroAutor autor del llibro. 
     */
    public String getLibroAutor() {
        return libroAutor;
    }
    /**
     * Método para modificar el autor del libro.
     * @param libroAutor nuevo autor del libro.
     */
    public void setLibroAutor(String libroAutor) {
        this.libroAutor = libroAutor;
    }
    /**
     * Método para obtener la cantiad total de ejemplares del libro.
     * @return libroCopias cantidad de ejemplares del libro.
     */
    public int getLibroCopias() {
        return libroCopias;
    }
    /**
     * Método para modificar la cantidad de ejemplares del libro.
     * @param libroCopias nueva cantidad de ejemplares del libro.
     */
    public void setLibroCopias(int libroCopias) {
        this.libroCopias = libroCopias;
    }
    /**
     * Método para obtener el tema del libro.
     * @return libroTema categoría temática del libro.
     */
    public String getLibroTema() {
        return libroTema;
    }
    /**
     * Método para modificar el tema del libro.
     * @param libroTema nueva categoría temática del libro.
     */
    public void setLibroTema(String libroTema) {
        this.libroTema = libroTema;
    }
    /**
     * Método que genera argumento para imprimir información del libro.
     */
    @Override
    public String toString() {
        return "Libro [ID=" + libroId + ", Título=" + libroTitulo + ", Autor=" + libroAutor + 
               ", Copias=" + libroCopias + ", Tema=" + libroTema + "]";
    }
}