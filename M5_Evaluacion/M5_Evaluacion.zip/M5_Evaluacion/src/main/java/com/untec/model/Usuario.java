package com.untec.model;
/**
 * Clase que gestiona la entidad Usuario.
 */
public class Usuario {
	/**
	 * Atributos coincidentes con tabla usuario de BD Untec en MariaDB.
	 */
    private int usuarioId;
    private String usuarioNombre;
    private String usuarioEmail;
    private String usuarioPassword;
    private String usuarioRol;
    /**
     * Constructor vacío (obligatorio para especificaciones web de Java)
     */
    public Usuario() {
    }
    /**
     * Constructor completo con ID y Rol (para consultas a MariaDB).
     * @param usuarioId identificador del usuario.
     * @param usuarioNombre nombre del usuario.
     * @param usuarioEmail correo electrónico del usuario.
     * @param usuarioPassword contraseña del usuario.
     * @param usuarioRol admin con todos los permisoa o user con permisos restringidos.
     */
    public Usuario(int usuarioId, String usuarioNombre, String usuarioEmail, String usuarioPassword, String usuarioRol) {
        this.usuarioId = usuarioId;
        this.usuarioNombre = usuarioNombre;
        this.usuarioEmail = usuarioEmail;
        this.usuarioPassword = usuarioPassword;
        this.usuarioRol = usuarioRol;
    }
    /**
     * Constructor completo sin ID y sin Rol(para operaciones de agregación).
     * @param usuarioNombre nombre del usuario.
     * @param usuarioEmail correo electrónico del usuario.
     * @param usuarioPassword contraseña del usuario.
     */
    public Usuario(String usuarioNombre, String usuarioEmail, String usuarioPassword) {
        this.usuarioNombre = usuarioNombre;
        this.usuarioEmail = usuarioEmail;
        this.usuarioPassword = usuarioPassword;
    }
    /**
     * Método para obtener ID del usuario.
     * @return libroID identificador del usuario.
     */
    public int getUsuarioId() {
        return usuarioId;
    }
    /**
     * Método para modificar el ID del usuario.
     * @param usuarioId nuevo ID dek usuario.
     */
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
    /**
     * Método para obtener nombre del usuario.
     * @return usuarioNombre nombre del usuario. 
     */
    public String getUsuarioNombre() {
        return usuarioNombre;
    }
    /**
     * Método para modificar el nombre del usuario.
     * @param usuarioNombre nuevo nombre de usuario.
     */
    public void setUsuarioNombre(String usuarioNombre) {
        this.usuarioNombre = usuarioNombre;
    }
    /**
     * Método para obtener el correo electrónico del usuario.
     * @return usuarioEmail correo electrónico del usuario.
     */
    public String getUsuarioEmail() {
        return usuarioEmail;
    }
    /**
     * Método para modificar el correo electrónico del usuario.
     * @param usuarioEmail nuevo correo electrónico del usuario.
     */
    public void setUsuarioEmail(String usuarioEmail) {
        this.usuarioEmail = usuarioEmail;
    }
    /**
     * Método para obtener el password del usuario.
     * @return usarioPassword contraseña del usuario.
     */
    public String getUsuarioPassword() {
        return usuarioPassword;
    }
    /**
     * Método para modificar el password del usuario.
     * @param usuarioPassword nueva contraseña del usuario.
     */
    public void setUsuarioPassword(String usuarioPassword) {
        this.usuarioPassword = usuarioPassword;
    }
    /**
     * Método para obtener el rol del usuario.
     * @return usarioRol rol del usuario (admin o user).
     */
    public String getUsuarioRol() {
        return usuarioRol;
    }
    /**
     * Método para modificar el rol del usuario.
     * @param usarioRol rol del usuario (admin o user).
     */
    public void setUsuarioRol(String usuarioRol) {
        this.usuarioRol = usuarioRol;
    }
    /**
     * Método que genera argumento para imprimir información del usuario.
     */
    @Override
    public String toString() {
        return "Usuario [ID=" + usuarioId + ", Nombre=" + usuarioNombre + ", Email=" + usuarioEmail + "]";
    }
}