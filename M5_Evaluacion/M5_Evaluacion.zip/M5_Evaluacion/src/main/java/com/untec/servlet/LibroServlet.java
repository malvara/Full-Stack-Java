package com.untec.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import javax.servlet.RequestDispatcher;

import com.untec.dao.LibroDAO;
import com.untec.model.Libro;

/**
 * Servlet controla la asignación de libros a lectores y
 * llama a consultas avanzadas que cruzan datos con alias 
 * de texto, permitiendo filtros avanzados.
 */
@WebServlet("/Libroweb")
public class LibroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LibroDAO libroDAO = new LibroDAO();
	/**
	 * Constructor por defecto.
	 */
    public LibroServlet() {
    	super();
    }
    /**
     * Método que atiende peticiones de lectura o eliminación de datos.
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String opcion = request.getParameter("opcion");
		// Elimina Libro de la BD Untec en MariaDB.
        if ("eliminar".equals(opcion)) {
            int id = Integer.parseInt(request.getParameter("id"));
            libroDAO.eliminar(id);
            // Redirige de vuelta al Servlet para refrescar la lista limpia en el navegador
            response.sendRedirect("Libroweb");
            return;
        }
		// Lista todos los libros de Untec.
		List<Libro> listaDeLibros = libroDAO.listarTodos();
		request.setAttribute("listaLibrosWeb", listaDeLibros);
		RequestDispatcher dispatcher = request.getRequestDispatcher("catalogo.jsp");
        dispatcher.forward(request, response);
	}
	/**
	 * Método que atiende peticiones de agregación o actualización de datos.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// Configura configuración de tildes en Tomcat.
		request.setCharacterEncoding("UTF-8");
		// Captura parámetros del formulario HTML
        String idStr = request.getParameter("txtId");
        String titulo = request.getParameter("txtTitulo");
        String autor = request.getParameter("txtAutor");
        int copias = Integer.parseInt(request.getParameter("txtCopias"));
        String tema = request.getParameter("txtTema");
        // Construye el objeto modelo con los datos recolectados
        Libro libro = new Libro(titulo, autor, copias, tema);
        // Agregar y actualizar datos de un libro.
        if (idStr == null || idStr.isEmpty()) {
            // Si el ID viene vacío en el formulario, significa que es un libro NUEVO
            libroDAO.agregar(libro);
        } else {
            // Si el ID ya trae un número, significa que estamos EDITANDO un libro existente
            libro.setLibroId(Integer.parseInt(idStr));
            libroDAO.actualizar(libro);
        }
        // Redirige al listado general para visualizar cambios inmediatamente.
        response.sendRedirect("Libroweb");
	}
}
