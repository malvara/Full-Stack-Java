<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>UNTEC - Gestión de Usuarios</title>
	<link rel="stylesheet" type="text/css" href="css/estilo01.css">
</head>
<body>
<div class="nav-bar-untec">
    <p class="nav-usuario">Usuario: <strong>${usuarioSesion.usuarioNombre}</strong> (<span style="color: #16a085; font-weight: bold;">${usuarioSesion.usuarioRol}</span>)</p>
    <div class="nav-menu-links">
        <a href="Libroweb" class="nav-link-item">Libros</a>
        <a href="Prestamoweb" class="nav-link-item">Préstamos</a>
        <c:if test="${usuarioSesion.usuarioRol == 'admin'}">
            <a href="Usuarioweb" class="nav-link-item">Usuarios</a>
        </c:if>
        <a href="LogoutServlet" class="btn-logout">Salir</a>
    </div>
</div>
<div class="formulario-container">
<h3 id="form-titulo">Registrar Nuevo Lector</h3>
<form action="Usuarioweb" method="POST">
	<input type="hidden" id="txtId" name="txtId">            
	<div style="display: flex; gap: 15px; margin-bottom: 15px;">
		<div style="flex: 1;">
			<label>Nombre Completo:</label>
			<input type="text" id="txtNombre" name="txtNombre" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		<div style="flex: 1;">
			<label>Correo Electrónico:</label>
			<input type="email" id="txtEmail" name="txtEmail" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		<div style="flex: 1;">
			<label>Contraseña:</label>
			<input type="password" id="txtPassword" name="txtPassword" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
	</div>            
	<button type="submit" class="btn-principal" style="background-color: #2ecc71; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">Guardar Lector</button>
	<button type="button" class="btn-cancelar" onclick="limpiarFormulario()" style="background-color: #95a5a6; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; display:none;" id="btnCancel">Cancelar</button>
</form>
</div>
<div class="tabla-container">
<h2>Administración de Lectores</h2>
<p style="text-align: right;">
	<a href="Libroweb" class="btn-secundario">← Ver Catálogo de Libros</a>
</p>
<table>
<thead>
	<tr>
		<th>ID Usuario</th>
		<th>Nombre Completo</th>
		<th>Correo Electrónico</th>
		<th>Acciones</th>
	</tr>
</thead>
<tbody>
<c:forEach var="usr" items="${listaUsuariosWeb}">
	<tr>
		<td><strong>${usr.usuarioId}</strong></td>
		<td>${usr.usuarioNombre}</td>
		<td>${usr.usuarioEmail}</td>
		<td>
			<button class="btn-editar" 
				onclick="cargarDatos('${usr.usuarioId}', '${usr.usuarioNombre}', '${usr.usuarioEmail}', '${usr.usuarioPassword}')"
				style="background: #f1c40f; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-right: 5px;">
				Editar
			</button>
		</td>
		<td>
			<a 
				href="Usuarioweb?opcion=eliminar&id=${usr.usuarioId}" 
				class="btn-eliminar" 
				onclick="return confirm('¿Seguro que deseas eliminar a este lector?');">
				Eliminar
			</a>
		</td>
	</tr>
</c:forEach>
</tbody>
</table>
</div>
<script>
	function cargarDatos(id, nombre, email, password) {
	    document.getElementById('txtId').value = id;
	    document.getElementById('txtNombre').value = nombre;
	    document.getElementById('txtEmail').value = email;
	    document.getElementById('txtPassword').value = password;
	    
	    document.getElementById('form-titulo').innerText = "Modificar Lector (ID: " + id + ")";
	    document.getElementById('btnCancel').style.display = "inline-block";
	}
	function limpiarFormulario() {
	    document.getElementById('txtId').value = "";
	    document.getElementById('txtNombre').value = "";
	    document.getElementById('txtEmail').value = "";
	    document.getElementById('txtPassword').value = "";
	    
	    document.getElementById('form-titulo').innerText = "📝 Registrar Nuevo Lector";
	    document.getElementById('btnCancel').style.display = "none";
	}
</script>
</body>
</html>