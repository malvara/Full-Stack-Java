<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>UNTEC - Gestión de Préstamos</title>
<link rel="stylesheet" type="text/css" href="css/estilo01.css">
</head>
<body>
<div class="nav-bar-untec">
    <p class="nav-usuario">Usuario: <strong>${usuarioSesion.usuarioNombre}</strong> (<span style="color: #16a085; font-weight: bold;">${usuarioSesion.usuarioRol}</span>)</p>
    <div class="nav-menu-links">
        <a href="Libroweb" class="nav-link-item">Libros</a>
        <a href="Prestamoweb" class="nav-link-item">Préstamos</a>
        <c:if test="${usuarioSesion.usuarioRol == 'admin'}">
            <a href="Usuarioweb" class="nav-link-item">Usuarios</a>
        </c:if>
        <a href="LogoutServlet" class="btn-logout">Salir</a>
    </div>
</div>
<div class="formulario-container" style="max-width: 950px; margin: 20px auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">        
<c:choose>
<c:when test="${usuarioSesion.usuarioRol == 'admin'}">
	<h3>Registrar Nueva Solicitud de Préstamo (Panel Admin)</h3>
	<form action="Prestamoweb" method="POST">
		<div style="display: flex; gap: 20px; align-items: flex-end;">
			<div style="flex: 1;">
			<label style="font-weight: bold; display: block; margin-bottom: 5px;">Seleccionar Libro:</label>
			<select name="selectLibro" required style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc;">
				<option value="">-- Elige un título disponible --</option>
				<c:forEach var="lib" items="${listaLibrosMenu}">
					<option value="${lib.libroId}">${lib.libroTitulo} (${lib.libroAutor})</option>
				</c:forEach>
			</select>
		</div>
		<div style="flex: 1;">
			<label style="font-weight: bold; display: block; margin-bottom: 5px;">Seleccionar Lector:</label>
			<select name="selectUsuario" required style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc;">
				<option value="">-- Elige el lector asignado --</option>
				<c:forEach var="usr" items="${listaUsuariosMenu}">
					<option value="${usr.usuarioId}">${usr.usuarioNombre} [${usr.usuarioEmail}]</option>
				</c:forEach>
			</select>
		</div>
			<div>
				<button type="submit" class="btn-principal">Otorgar Préstamo</button>
			</div>
		</div>
	</form>
</c:when>
<c:otherwise>
	<h3>Solicitar un Libro para Mí</h3>
	<form action="Prestamoweb" method="POST">
		<input type="hidden" name="selectUsuario" value="${usuarioSesion.usuarioId}">
		<div style="display: flex; gap: 20px; align-items: flex-end;">
			<div style="flex: 2;">
				<label style="font-weight: bold; display: block; margin-bottom: 5px;">Selecciona el libro que deseas pedir prestado:</label>
				<select name="selectLibro" required style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc;">
					<option value="">-- Buscar título en el catálogo --</option>
					<c:forEach var="lib" items="${listaLibrosMenu}">
						<option value="${lib.libroId}">${lib.libroTitulo} - ${lib.libroAutor}</option>
					</c:forEach>
				</select>
			</div>
			<div>
				<button type="submit" class="btn-principal" style="background-color: #3498db;">Reservar Libro</button>
			</div>
		</div>
	</form>
</c:otherwise>
</c:choose>
</div>
<div class="tabla-container" style="max-width: 950px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
	<h2>
		<c:out value="${usuarioSesion.usuarioRol == 'admin' ? 'Control Global de Préstamos' : 'Mis Préstamos Activos'}" />
	</h2>
	<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
		<div>
			<p>Usuario actual: <strong>${usuarioSesion.usuarioNombre}</strong> (<span style="color: #2980b9; font-weight: bold;">${usuarioSesion.usuarioRol}</span>)</p>
		</div>
	<div>
		<a href="Libroweb" class="btn-secundario" style="margin-right: 15px;">📚 Catálogo de Libros</a>
		<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
			<a href="Usuarioweb" class="btn-secundario">Control de Lectores</a>
		</c:if>
	</div>
</div>
<table>
	<thead>
		<tr>
			<th>ID Registro</th>
			<th>Título del Libro</th>
			<th>Lector Responsable</th>
			<th>Fecha de Préstamo</th>
			<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
				<th>Acciones</th>
			</c:if>
		</tr>
	</thead>
	<tbody>
		<c:forEach var="pres" items="${listaPrestamosWeb}">
			<tr>
				<td><strong>${pres.prestamoId}</strong></td>
				<td style="color: #2980b9; font-weight: 500;">${pres.libroTituloTexto}</td>
				<td>${pres.usuarioNombreTexto}</td>
				<td>
					<span class="badge" style="background-color: #7f8c8d;">${pres.prestamoFecha}</span>
				</td>
				<%-- El Lector no puede auto-eliminarse préstamos o marcar devoluciones arbitrarias --%>
				<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
					<td>
						<a 
							href="Prestamoweb?opcion=eliminar&id=${pres.prestamoId}" 
							class="btn-eliminar" 
							onclick="return confirm('¿Confirmas la devolución física del libro?');">
							Devolución
						</a>
					</td>
				</c:if>
			</tr>
		</c:forEach>
	</tbody>
</table>
</div>
</body>
</html>