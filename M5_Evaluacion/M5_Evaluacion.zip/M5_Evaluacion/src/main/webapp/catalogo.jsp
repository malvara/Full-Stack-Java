<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>UNTEC - Catálogo</title>
	<link rel="stylesheet" type="text/css" href="css/estilo01.css">
</head>
<body>
<div class="nav-bar-untec">
    <p class="nav-usuario">Usuario: <strong>${usuarioSesion.usuarioNombre}</strong> (<span style="color: #16a085; font-weight: bold;">${usuarioSesion.usuarioRol}</span>)</p>
    <div class="nav-menu-links">
        <a href="Libroweb" class="nav-link-item">Libros</a>
        <a href="Prestamoweb" class="nav-link-item">Préstamos</a>
        <c:if test="${usuarioSesion.usuarioRol == 'admin'}">
            <a href="Usuarioweb" class="nav-link-item">Usuarios</a>
        </c:if>
        <a href="LogoutServlet" class="btn-logout">Salir</a>
    </div>
</div>
<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
	<div class="formulario-container" style="max-width: 900px; margin: 20px auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
	<h3 id="form-titulo">Registrar Nuevo Libro</h3>            
	<form action="Libroweb" method="POST">
		<input type="hidden" id="txtId" name="txtId">                
		<div style="display: flex; gap: 15px; margin-bottom: 15px;">
		<div style="flex: 2;">
			<label>Título del Libro:</label>
			<input type="text" id="txtTitulo" name="txtTitulo" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		<div style="flex: 2;">
			<label>Autor:</label>
			<input type="text" id="txtAutor" name="txtAutor" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		</div>                
		<div style="display: flex; gap: 15px; margin-bottom: 15px;">
		<div style="flex: 1;">
			<label>Copias:</label>
			<input type="number" id="txtCopias" name="txtCopias" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		<div style="flex: 2;">
			<label>Temática / Género:</label>
			<input type="text" id="txtTema" name="txtTema" required style="width: 100%; padding: 8px; margin-top: 5px;">
		</div>
		</div>                
		<button type="submit" class="btn-principal">Guardar Libro</button>
		<button type="button" class="btn-cancelar" onclick="limpiarFormulario()" style="background-color: #95a5a6; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; display:none;" id="btnCancel">Cancelar</button>
	</form>
	</div>
</c:if>
<div class="tabla-container">
<h2>Colección Digital de Libros</h2>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
	<p>Bienvenido(a): <strong>${usuarioSesion.usuarioNombre}</strong> (<span style="color: #16a085; font-weight: bold;">${usuarioSesion.usuarioRol}</span>)</p>
	<div>
	<a href="Prestamoweb" class="btn-secundario" style="margin-right: 15px;">Ver Préstamos</a>
	<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
		<a href="Usuarioweb" class="btn-secundario">Control de Lectores</a>
	</c:if>
	</div>
</div>

<table>
	<thead>
		<tr>
		<th>ID</th>
		<th>Título</th>
		<th>Autor</th>
		<th>Temática</th>
		<th>Copias</th>
		<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
        	<th>Acciones</th>
        </c:if>
		</tr>
	</thead>
<tbody>
<c:forEach var="libro" items="${listaLibrosWeb}">
	<tr>
		<td><strong>${libro.libroId}</strong></td>
		<td>${libro.libroTitulo}</td>
		<td>${libro.libroAutor}</td>
		<td><span class="badge">${libro.libroTema}</span></td>
		<td>${libro.libroCopias}</td>
		<c:if test="${usuarioSesion.usuarioRol == 'admin'}">
		<td>
			<button class="btn-editar" 
				onclick="cargarDatos('${libro.libroId}', '${libro.libroTitulo}', '${libro.libroAutor}', '${libro.libroCopias}', '${libro.libroTema}')"
				style="background: #f1c40f; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-right: 5px;">
				Editar
			</button>
			<a 
				href="Libroweb?opcion=eliminar&id=${libro.libroId}"
				class="btn-eliminar" 
				style="background: #e74c3c; color: white; text-decoration: none; padding: 5px 10px; border-radius: 4px; display: inline-block;"
				onclick="return confirm('¿Seguro que deseas eliminar este libro?');">
				Eliminar
			</a >
		</td>
		</c:if>
	</tr>
</c:forEach>
</tbody>
</table>
</div>
</body>
<script>
	function cargarDatos(id, titulo, autor, copias, tema) {
	    document.getElementById('txtId').value = id;
	    document.getElementById('txtTitulo').value = titulo;
	    document.getElementById('txtAutor').value = autor;
	    document.getElementById('txtCopias').value = copias;
	    document.getElementById('txtTema').value = tema;
	    
	    document.getElementById('form-titulo').innerText = "🔄 Modificar Libro (ID: " + id + ")";
	    document.getElementById('btnCancel').style.display = "inline-block";
	}
	function limpiarFormulario() {
	    document.getElementById('txtId').value = "";
	    document.getElementById('txtTitulo').value = "";
	    document.getElementById('txtAutor').value = "";
	    document.getElementById('txtCopias').value = "";
	    document.getElementById('txtTema').value = "";
	    
	    document.getElementById('form-titulo').innerText = "📝 Registrar Nuevo Libro";
	    document.getElementById('btnCancel').style.display = "none";
	}
</script>
</html>