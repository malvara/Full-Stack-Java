<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>UNTEC - Inicio</title>
<link rel="stylesheet" type="text/css" href="css/estilo01.css">
</head>
<body>
<div class="login-wrapper">
	<div class="login-container">
    <div style="text-align: center; margin-bottom: 25px;">
		<h2 style="margin: 0; color: #2c3e50;">Sistema UNTEC</h2>
		<small style="color: #7f8c8d;">Biblioteca Digital</small>
	</div>
	<c:if test="${not empty mensajeError}">
		<div class="alert-error">
			${mensajeError}
		</div>
	</c:if>
	<form action="Usuarioweb" method="POST">
		<input type="hidden" name="opcion" value="login">
		<div class="form-group">
			<label for="txtEmail">Correo Electrónico:</label>
			<input type="email" id="txtEmail" name="txtEmail" placeholder="ejemplo@untec.cl" required>
		</div>
		<div class="form-group">
		    <label for="txtPassword">Contraseña:</label>
		    <input type="password" id="txtPassword" name="txtPassword" placeholder="••••••••" required>
		</div>
		<div style="margin-top: 25px;">
			<button type="submit" class="btn-principal" style="width: 100%; padding: 12px;">
				Ingresar al Sistema
			</button>
		</div>
	</form> 
	</div>
</div>
</body>
</html>